#include <stdio.h>

int  main()
{
	double a=3412123.456;
	printf("%lf",a/10000000.0);
	
}
