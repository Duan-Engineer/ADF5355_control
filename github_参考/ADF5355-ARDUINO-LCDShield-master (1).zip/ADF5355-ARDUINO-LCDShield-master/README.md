# ADF5355-ARDUINO-LCDShield
ADF5355 synthesizer is driven by an Arduino and LCD Schield
by Alain Fort F1CJN and Dave Brink (64 bits routines)
January 11,2018. Prototype version.
Doc V1 correction for OL at 26 MHz (and not 25 !)
