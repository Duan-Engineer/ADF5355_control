# ADF5355_sig_gen
ADF5355 signal generator arduino code
Code to use a ADF5355 as a signal generator covering the frequency range 54 MHz to 13.6GHz. 
The code is aimed at a SAMD21 32 bit processor which is supported in the Arduino IDE.
Details of the hardware are at 
https://gm8bjf.joomla.com/articles/19-a-52-mhz-to-13-6-ghz-signal-generator-based-on-the-adf5355
Code is also available to use the lower cost Maple Mini board as the microcontroller.
